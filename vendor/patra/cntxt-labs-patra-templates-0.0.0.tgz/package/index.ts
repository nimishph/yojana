import { join } from 'node:path';

/** The directory of one of patra's templates, for `loadTemplate`. */
export function templateDir(name: 'review-document'): string {
  return join(import.meta.dir, name);
}
