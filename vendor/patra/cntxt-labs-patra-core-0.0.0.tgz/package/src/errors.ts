/** Errors carry a stable code, so hosts and apps can act on them without parsing messages. */
export class PatraError extends Error {
  readonly code: string;
  readonly hint: string | undefined;

  constructor(code: string, message: string, options?: { hint?: string; cause?: unknown }) {
    super(message, options?.cause === undefined ? undefined : { cause: options.cause });
    this.name = 'PatraError';
    this.code = code;
    this.hint = options?.hint;
  }
}
