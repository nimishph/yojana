/** A problem with a template or with content, located precisely enough to fix. */
export interface Problem {
  /** File the problem is in, relative to the template directory; `content` for content problems. */
  readonly file: string;
  /** JSON Pointer to the place in that file or content, `''` for the whole of it. */
  readonly at: string;
  readonly code: string;
  readonly message: string;
}
