import Mustache from 'mustache';
import { escapeHtml, type Mark, renderDiff, renderMarkdown, SafeHtml } from './format.ts';
import type { Problem } from './problem.ts';
import type { LoadedTemplate } from './template.ts';

/**
 * Rendering: content in, HTML out, through a loaded template. Templates are logic-less Mustache;
 * every `{{value}}` is escaped unless it is a `SafeHtml` patra made itself, which is how formatted
 * values (Markdown, diffs) reach the page. Templates cannot output raw values at all: `{{{x}}}`,
 * `{{& x}}` and delimiter changes are refused when a template loads (see `templateProblems`).
 *
 * The page is rendered with every part available as a Mustache partial (`{{> section}}`), and
 * `patra` holds values the host provides (document id, token, mode), so a template can use them.
 */

export type RenderResult =
  | { readonly ok: true; readonly html: string }
  | { readonly ok: false; readonly problems: readonly Problem[] };

const escapeValue = (value: unknown): string =>
  value instanceof SafeHtml ? value.html : escapeHtml(String(value));

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function marksOf(value: unknown): Mark[] {
  if (!Array.isArray(value)) return [];
  return value.flatMap((m) =>
    isRecord(m) && typeof m.text === 'string' && typeof m.id === 'string'
      ? [{ text: m.text, id: m.id }]
      : [],
  );
}

/**
 * Replace formatted values with their rendered HTML, everywhere in the content:
 *
 *   {kind: 'markdown', source, marks?}  -> SafeHtml
 *   {kind: 'diff', before, after}       -> SafeHtml
 *
 * Other objects and arrays are walked; strings, numbers and booleans are left to be escaped.
 *
 * An item nested in another item (a reply in a thread, a note in a callout) reads only its own
 * values: a key it lacks that an enclosing item has is set to null. Mustache would otherwise look
 * the key up in the enclosing item, so a reply without `agent` would show its thread's `agent`.
 * `item` says `value` is itself an item (one rendered as a part), not the page's content.
 */
export function prepare(value: unknown, item = false): unknown {
  return prepareIn(value, new Set(), item);
}

function prepareIn(value: unknown, enclosing: ReadonlySet<string>, item: boolean): unknown {
  if (Array.isArray(value)) return value.map((v) => prepareIn(v, enclosing, true));
  if (!isRecord(value)) return value;
  if (value.kind === 'markdown' && typeof value.source === 'string') {
    return renderMarkdown(value.source, marksOf(value.marks));
  }
  if (
    value.kind === 'diff' &&
    typeof value.before === 'string' &&
    typeof value.after === 'string'
  ) {
    return renderDiff(value.before, value.after);
  }
  const inner = item ? new Set([...enclosing, ...Object.keys(value)]) : enclosing;
  const own = Object.entries(value).map(([k, v]) => [k, prepareIn(v, inner, false)]);
  const shadowed = item
    ? [...enclosing].filter((k) => !Object.hasOwn(value, k)).map((k) => [k, null])
    : [];
  return Object.fromEntries([...shadowed, ...own]);
}

function partials(template: LoadedTemplate): Record<string, string> {
  return Object.fromEntries([...template.parts].map(([name, part]) => [name, part.html]));
}

/** The whole page. Content is checked against the template first; nothing renders if it fails. */
export function renderPage(
  template: LoadedTemplate,
  content: unknown,
  patra: Readonly<Record<string, unknown>> = {},
): RenderResult {
  const problems = template.check(content);
  if (problems.length > 0) return { ok: false, problems };
  const view = { ...(prepare(content) as Record<string, unknown>), patra };
  return {
    ok: true,
    html: Mustache.render(template.page, view, partials(template), { escape: escapeValue }),
  };
}

/**
 * One part, for one item: what a partial update swaps into the page. The item is the element of
 * the part's collection (or, for a one-off part, the view the part needs).
 */
export function renderPart(
  template: LoadedTemplate,
  partName: string,
  item: unknown,
  patra: Readonly<Record<string, unknown>> = {},
): RenderResult {
  const part = template.parts.get(partName);
  if (part === undefined) {
    return {
      ok: false,
      problems: [{ file: 'content', at: '', code: 'UNKNOWN_PART', message: `no part ${partName}` }],
    };
  }
  if (part.key !== undefined) {
    const key = isRecord(item) ? item[part.key] : undefined;
    if (typeof key !== 'string' || key === '') {
      return {
        ok: false,
        problems: [
          {
            file: 'content',
            at: '',
            code: 'MISSING_KEY',
            message: `an item of ${partName} needs a string ${part.key}`,
          },
        ],
      };
    }
  }
  const view = isRecord(item)
    ? { ...(prepare(item, part.key !== undefined) as Record<string, unknown>), patra }
    : { patra };
  return {
    ok: true,
    html: Mustache.render(part.html, view, partials(template), { escape: escapeValue }),
  };
}

/**
 * The page head a host passes as `patra.head`: the theme's tokens, then the template's layout,
 * in one `<style>`. Stylesheets come from the template and theme authors, not from content; any
 * `</style` inside them is broken up so a stylesheet cannot end its own element.
 */
export function pageHead(
  template: LoadedTemplate,
  themeCss: string,
  extra: readonly string[] = [],
): SafeHtml {
  const css = [themeCss, ...template.styles.map((s) => s.css)]
    .join('\n')
    .replace(/<\/style/gi, '<\\/style');
  return new SafeHtml([`<style>\n${css}\n</style>`, ...extra].join('\n'));
}
