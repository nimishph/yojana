import { existsSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { type OutputUnit, type Schema, Validator } from '@cfworker/json-schema';
import type { ActionManifest, PartManifest, TemplateManifest } from './contract.ts';
import { templateProblems } from './markup.ts';
import type { Problem } from './problem.ts';

export type { Problem } from './problem.ts';

/**
 * Loading a template: `<dir>/template.json` and the files it names, checked before anything is
 * rendered. A bad template is reported as a list of problems (which file, where in it, what is
 * wrong), never thrown halfway through a render.
 *
 * The loaded template also checks content: against its JSON Schema, and against what its parts
 * need (each collection is an array, each item has a unique key).
 */

export interface LoadedPart extends PartManifest {
  readonly name: string;
  readonly html: string;
}

export interface LoadedTemplate {
  readonly dir: string;
  readonly manifest: TemplateManifest;
  readonly page: string;
  readonly parts: ReadonlyMap<string, LoadedPart>;
  readonly schema: Schema;
  /** The template's stylesheets, in order, as written. */
  readonly styles: readonly { readonly file: string; readonly css: string }[];
  /** Problems with content for this template; empty when it can be rendered. */
  check(content: unknown): Problem[];
}

export type LoadResult =
  | { readonly ok: true; readonly template: LoadedTemplate }
  | { readonly ok: false; readonly problems: readonly Problem[] };

const ID = /^[a-z][a-z0-9-]{0,63}$/;
const SEMVER = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
const TOKEN = /^--[a-z][a-z0-9-]*$/;
const MANIFEST = 'template.json';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** JSON Pointer segment escaping (RFC 6901). */
function segment(key: string): string {
  return key.replaceAll('~', '~0').replaceAll('/', '~1');
}

export function loadTemplate(dir: string): LoadResult {
  const problems: Problem[] = [];
  const problem = (file: string, at: string, code: string, message: string) =>
    problems.push({ file, at, code, message });

  const readText = (file: string, at: string): string | undefined => {
    const path = join(dir, file);
    if (!existsSync(path)) {
      problem(MANIFEST, at, 'MISSING_FILE', `${file} does not exist in ${dir}`);
      return undefined;
    }
    return readFileSync(path, 'utf8');
  };
  const readJson = (file: string, at: string): unknown => {
    const text = readText(file, at);
    if (text === undefined) return undefined;
    try {
      return JSON.parse(text);
    } catch (error) {
      problem(file, '', 'INVALID_JSON', `${file} is not valid JSON: ${String(error)}`);
      return undefined;
    }
  };

  const raw = readJson(MANIFEST, '');
  if (!isRecord(raw)) {
    if (raw !== undefined)
      problem(MANIFEST, '', 'INVALID_MANIFEST', 'template.json must be an object');
    return { ok: false, problems };
  }

  const text = (key: string, pattern?: RegExp, hint?: string): string => {
    const value = raw[key];
    if (typeof value !== 'string' || value.trim() === '') {
      problem(MANIFEST, `/${key}`, 'INVALID_MANIFEST', `${key} must be a non-empty string`);
      return '';
    }
    if (pattern !== undefined && !pattern.test(value)) {
      problem(
        MANIFEST,
        `/${key}`,
        'INVALID_MANIFEST',
        `${key} ${hint ?? 'is not valid'}: ${value}`,
      );
    }
    return value;
  };
  const id = text('id', ID, 'must be lowercase kebab-case');
  const version = text('version', SEMVER, 'must be semver (1.2.3)');
  const description = text('description');
  const pageFile = text('page');
  const schemaFile = text('schema');

  const page = pageFile === '' ? undefined : readText(pageFile, '/page');

  // Parts.
  const parts = new Map<string, LoadedPart>();
  const rawParts = raw.parts ?? {};
  if (!isRecord(rawParts)) {
    problem(MANIFEST, '/parts', 'INVALID_MANIFEST', 'parts must be an object of name -> part');
  } else {
    for (const [name, value] of Object.entries(rawParts)) {
      const at = `/parts/${segment(name)}`;
      if (!ID.test(name))
        problem(MANIFEST, at, 'INVALID_MANIFEST', `part name must be kebab-case: ${name}`);
      if (!isRecord(value) || typeof value.file !== 'string') {
        problem(MANIFEST, at, 'INVALID_MANIFEST', 'a part needs a file');
        continue;
      }
      const collection = value.collection;
      const key = value.key;
      if (
        collection !== undefined &&
        (typeof collection !== 'string' || !collection.startsWith('/'))
      ) {
        problem(
          MANIFEST,
          `${at}/collection`,
          'INVALID_MANIFEST',
          'collection must be a JSON Pointer such as /sections',
        );
        continue;
      }
      if (
        (collection === undefined) !== (key === undefined) ||
        (key !== undefined && typeof key !== 'string')
      ) {
        problem(
          MANIFEST,
          at,
          'INVALID_MANIFEST',
          'collection and key go together: both or neither',
        );
        continue;
      }
      const html = readText(value.file, `${at}/file`);
      if (html === undefined) continue;
      parts.set(name, {
        name,
        file: value.file,
        html,
        ...(typeof collection === 'string' ? { collection } : {}),
        ...(typeof key === 'string' ? { key } : {}),
      });
    }
  }

  // Markup: syntax, no raw output, no delimiter changes, partials that name real parts.
  const partNames = new Set(isRecord(rawParts) ? Object.keys(rawParts) : []);
  if (page !== undefined) problems.push(...templateProblems(pageFile, page, partNames));
  for (const part of parts.values())
    problems.push(...templateProblems(part.file, part.html, partNames));

  // Actions.
  const actions: Record<string, ActionManifest> = {};
  const rawActions = raw.actions ?? {};
  if (!isRecord(rawActions)) {
    problem(
      MANIFEST,
      '/actions',
      'INVALID_MANIFEST',
      'actions must be an object of name -> action',
    );
  } else {
    for (const [name, value] of Object.entries(rawActions)) {
      const at = `/actions/${segment(name)}`;
      if (!ID.test(name))
        problem(MANIFEST, at, 'INVALID_MANIFEST', `action name must be kebab-case: ${name}`);
      if (!isRecord(value) || typeof value.part !== 'string') {
        problem(MANIFEST, at, 'INVALID_MANIFEST', 'an action needs the part it acts on');
        continue;
      }
      const target =
        rawParts !== undefined && isRecord(rawParts) ? rawParts[value.part] : undefined;
      if (target === undefined) {
        problem(MANIFEST, `${at}/part`, 'UNKNOWN_PART', `no part ${value.part}`);
      } else if (!isRecord(target) || target.key === undefined) {
        problem(
          MANIFEST,
          `${at}/part`,
          'INVALID_MANIFEST',
          `${value.part} has no key, so an action cannot say which item it is on`,
        );
      }
      if (
        value.form !== undefined &&
        (typeof value.form !== 'string' ||
          !isRecord(rawParts) ||
          rawParts[value.form] === undefined)
      ) {
        problem(
          MANIFEST,
          `${at}/form`,
          'UNKNOWN_PART',
          `no part ${String(value.form)} for the form`,
        );
      }
      const fields = value.fields ?? [];
      if (!Array.isArray(fields) || !fields.every((f) => typeof f === 'string')) {
        problem(
          MANIFEST,
          `${at}/fields`,
          'INVALID_MANIFEST',
          'fields must be a list of field names',
        );
        continue;
      }
      const defaults: Record<string, string> = {};
      if (value.defaults !== undefined) {
        if (!isRecord(value.defaults)) {
          problem(
            MANIFEST,
            `${at}/defaults`,
            'INVALID_MANIFEST',
            'defaults must map a field to a JSON Pointer',
          );
        } else {
          for (const [field, pointer] of Object.entries(value.defaults)) {
            if (!fields.includes(field)) {
              problem(
                MANIFEST,
                `${at}/defaults/${segment(field)}`,
                'INVALID_MANIFEST',
                `${field} is not one of the action's fields`,
              );
            } else if (typeof pointer !== 'string' || !pointer.startsWith('/')) {
              problem(
                MANIFEST,
                `${at}/defaults/${segment(field)}`,
                'INVALID_MANIFEST',
                'a default must be a JSON Pointer such as /editable/text',
              );
            } else {
              defaults[field] = pointer;
            }
          }
        }
      }
      actions[name] = {
        part: value.part,
        ...(typeof value.form === 'string' ? { form: value.form } : {}),
        fields,
        ...(Object.keys(defaults).length > 0 ? { defaults } : {}),
      };
    }
  }

  // Stylesheets.
  const styles: { file: string; css: string }[] = [];
  const rawStyles = raw.styles ?? [];
  if (!Array.isArray(rawStyles) || !rawStyles.every((f) => typeof f === 'string')) {
    problem(MANIFEST, '/styles', 'INVALID_MANIFEST', 'styles must be a list of CSS files');
  } else {
    rawStyles.forEach((file, index) => {
      const css = readText(file, `/styles/${index}`);
      if (css !== undefined) styles.push({ file, css });
    });
  }

  // Theme tokens.
  const rawTokens = raw.tokens ?? [];
  const tokens: string[] = [];
  if (!Array.isArray(rawTokens)) {
    problem(
      MANIFEST,
      '/tokens',
      'INVALID_MANIFEST',
      'tokens must be a list such as ["--bg", "--ink"]',
    );
  } else {
    rawTokens.forEach((token, index) => {
      if (typeof token === 'string' && TOKEN.test(token)) tokens.push(token);
      else
        problem(
          MANIFEST,
          `/tokens/${index}`,
          'INVALID_MANIFEST',
          `not a CSS custom property name: ${String(token)}`,
        );
    });
  }

  // Content schema.
  let schema: Schema | undefined;
  let validator: Validator | undefined;
  if (schemaFile !== '') {
    const rawSchema = readJson(schemaFile, '/schema');
    if (isRecord(rawSchema)) {
      try {
        schema = rawSchema as Schema;
        validator = new Validator(schema, '2020-12', false);
      } catch (error) {
        problem(
          schemaFile,
          '',
          'INVALID_SCHEMA',
          `the content schema does not compile: ${String(error)}`,
        );
      }
    } else if (rawSchema !== undefined) {
      problem(schemaFile, '', 'INVALID_SCHEMA', 'the content schema must be a JSON object');
    }
  }

  if (
    problems.length > 0 ||
    page === undefined ||
    schema === undefined ||
    validator === undefined
  ) {
    return { ok: false, problems };
  }

  const manifest: TemplateManifest = {
    id,
    version,
    description,
    page: pageFile,
    parts: Object.fromEntries([...parts].map(([name, part]) => [name, partManifest(part)])),
    schema: schemaFile,
    actions,
    tokens,
    ...(styles.length > 0 ? { styles: styles.map((s) => s.file) } : {}),
  };
  const checker = validator;
  return {
    ok: true,
    template: {
      dir,
      manifest,
      page,
      parts,
      styles,
      schema,
      check: (content) => [
        ...schemaProblems(checker, content),
        ...collectionProblems(parts, content),
      ],
    },
  };
}

function partManifest(part: LoadedPart): PartManifest {
  return {
    file: part.file,
    ...(part.collection === undefined ? {} : { collection: part.collection }),
    ...(part.key === undefined ? {} : { key: part.key }),
  };
}

/**
 * Wrapper keywords that only say "something deeper failed"; the deeper error is reported on its
 * own, so these would repeat it.
 */
const WRAPPERS = new Set([
  'properties',
  'items',
  'prefixItems',
  'allOf',
  '$ref',
  'additionalProperties',
  'unevaluatedProperties',
  'unevaluatedItems',
]);

/**
 * The validator also reports, as a `false` schema, each property `additionalProperties` looked at;
 * for a property that failed its own schema that only repeats the real error. On its own (an
 * unknown property) it is the real error, and says so plainly.
 */
const REPEATS = new Set([...WRAPPERS, 'false']);

function schemaProblems(validator: Validator, content: unknown): Problem[] {
  const result = validator.validate(content);
  if (result.valid) return [];
  const errors: readonly OutputUnit[] = result.errors;
  // Explained by an error further in, or by a real (not repeated) error at the same place.
  const explained = (e: OutputUnit) =>
    errors.some(
      (d) =>
        d !== e &&
        !WRAPPERS.has(d.keyword) &&
        (d.instanceLocation.startsWith(`${e.instanceLocation}/`) ||
          (d.instanceLocation === e.instanceLocation && !REPEATS.has(d.keyword))),
    );
  const seen = new Set<string>();
  const problems: Problem[] = [];
  for (const e of errors) {
    if (REPEATS.has(e.keyword) && explained(e)) continue;
    if (WRAPPERS.has(e.keyword)) continue;
    const at = e.instanceLocation.replace(/^#/, '');
    const message = e.keyword === 'false' ? `${at || 'this'} is not allowed here` : e.error;
    const id = `${at}\u0000${message}`;
    if (seen.has(id)) continue;
    seen.add(id);
    problems.push({ file: 'content', at, code: 'INVALID_CONTENT', message });
  }
  return problems;
}

/** Resolve a JSON Pointer (RFC 6901) in a value. */
export function resolvePointer(value: unknown, pointer: string): unknown {
  if (pointer === '') return value;
  let current: unknown = value;
  for (const raw of pointer.slice(1).split('/')) {
    const key = raw.replaceAll('~1', '/').replaceAll('~0', '~');
    if (Array.isArray(current)) current = current[Number(key)];
    else if (isRecord(current)) current = current[key];
    else return undefined;
  }
  return current;
}

function collectionProblems(parts: ReadonlyMap<string, LoadedPart>, content: unknown): Problem[] {
  const problems: Problem[] = [];
  for (const part of parts.values()) {
    if (part.collection === undefined || part.key === undefined) continue;
    const items = resolvePointer(content, part.collection);
    if (items === undefined) continue;
    if (!Array.isArray(items)) {
      problems.push({
        file: 'content',
        at: part.collection,
        code: 'NOT_A_COLLECTION',
        message: `part ${part.name} renders ${part.collection}, which must be a list`,
      });
      continue;
    }
    const seen = new Map<string, number>();
    items.forEach((item, index) => {
      const key = isRecord(item) ? item[part.key ?? ''] : undefined;
      const at = `${part.collection}/${index}`;
      if (typeof key !== 'string' || key === '') {
        problems.push({
          file: 'content',
          at,
          code: 'MISSING_KEY',
          message: `items of ${part.collection} need a string ${part.key} so ${part.name} can update one of them`,
        });
        return;
      }
      const first = seen.get(key);
      if (first !== undefined) {
        problems.push({
          file: 'content',
          at,
          code: 'DUPLICATE_KEY',
          message: `${part.key} ${key} is used by ${part.collection}/${first} as well`,
        });
      }
      seen.set(key, index);
    });
  }
  return problems;
}
