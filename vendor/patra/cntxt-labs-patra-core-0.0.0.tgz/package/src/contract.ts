/**
 * The patra contract: what a template declares, what an app hands patra to show, and how a
 * person's actions travel back to the app and what the app may answer. Nothing here knows about
 * any domain (plans, rules, digests); that is what lets one engine serve every tool.
 *
 * See docs/design.md for the reasoning; this file is the source of truth for the shapes.
 */

/** A template on disk: `<dir>/template.json` plus the files it names. */
export interface TemplateManifest {
  /** Stable id apps refer to, e.g. `review-document`. */
  readonly id: string;
  /** Version of this template's content contract (semver); a breaking schema change bumps major. */
  readonly version: string;
  readonly description: string;
  /** The page, an HTML file with placeholders. */
  readonly page: string;
  /** Pieces of the page that can be rendered on their own, for partial updates. */
  readonly parts: Readonly<Record<string, PartManifest>>;
  /** JSON Schema (2020-12) for the content this template accepts. */
  readonly schema: string;
  /** Stylesheets for the template's layout, using only theme tokens. */
  readonly styles?: readonly string[] | undefined;
  /** What a person can do on the page; each becomes an intent to the owning app. */
  readonly actions: Readonly<Record<string, ActionManifest>>;
  /** Theme tokens the template uses; a theme must define all of them. */
  readonly tokens: readonly string[];
}

export interface PartManifest {
  /** HTML file with placeholders, rendered with one item of content. */
  readonly file: string;
  /** JSON Pointer to the array of items this part renders, e.g. `/sections`; absent: one-off part. */
  readonly collection?: string | undefined;
  /** Field of an item that identifies it within the collection, e.g. `id`. */
  readonly key?: string | undefined;
}

export interface ActionManifest {
  /** The part an action is taken on; its item key becomes the intent's target. */
  readonly part: string;
  /** A part holding the form for the action, when it needs input. */
  readonly form?: string | undefined;
  /** Form fields sent as the intent's payload. */
  readonly fields: readonly string[];
  /**
   * Where a field's value starts when the form opens: a JSON Pointer into the item acted on,
   * e.g. `{"text": "/editable/text"}`. A form renders `{{values.<field>}}`; after a refusal those
   * are what the person typed instead.
   */
  readonly defaults?: Readonly<Record<string, string>> | undefined;
}

/**
 * Formatted values inside content. Apps never pass HTML: patra renders these itself, escaping
 * everything, so a template cannot be made to run what an app's data contains.
 */
export type Formatted =
  | {
      readonly kind: 'markdown';
      readonly source: string;
      /** Spans to mark (e.g. the quotes threads pin to); each becomes `<mark data-mark="id">`. */
      readonly marks?: readonly { readonly text: string; readonly id: string }[] | undefined;
    }
  | { readonly kind: 'diff'; readonly before: string; readonly after: string };

/** A person's action, sent to the app that owns the content. */
export interface Intent {
  /** Template id and the document's id as the app named it. */
  readonly template: string;
  readonly document: string;
  /** Declared action name, e.g. `edit`, `suggest`, `comment`, `accept`. */
  readonly action: string;
  /** The item acted on: part name and its key. */
  readonly target: { readonly part: string; readonly key: string };
  /**
   * The item's `version` as the page showed it, copied back unread. patra never interprets it;
   * the app uses it to refuse an action on content that has moved since.
   */
  readonly version?: string | undefined;
  /** Form fields, by name. */
  readonly payload: Readonly<Record<string, string>>;
  /** Who acted, as the host knows them. */
  readonly actor: string;
}

/** What the page should show after an intent the app accepted. */
export type Update =
  /** Re-render one item of a part with this content. */
  | {
      readonly kind: 'part';
      readonly part: string;
      readonly key: string;
      readonly content: unknown;
    }
  /** The change touches more than one part: reload the page. */
  | { readonly kind: 'page' };

export type IntentAnswer =
  | { readonly ok: true; readonly update: Update }
  | {
      readonly ok: false;
      /** Stable code, e.g. `STALE`, `INVALID`, `NOT_FOUND`. */
      readonly code: string;
      /** Shown to the person as written; say what happened and what to do. */
      readonly message: string;
      /** For `STALE`: the item's content now, so the page can show what changed. */
      readonly current?: unknown;
    };

/** The app's side: where content comes from, and what to do with intents. */
export interface ContentSource {
  /** The document's content for a template; undefined when there is no such document. */
  load(template: string, document: string): Promise<unknown | undefined>;
}

export type IntentHandler = (intent: Intent) => Promise<IntentAnswer>;

export function isRefusal(
  answer: IntentAnswer,
): answer is Extract<IntentAnswer, { readonly ok: false }> {
  return !answer.ok;
}
