import { existsSync, readFileSync } from 'node:fs';
import type { Problem } from './problem.ts';

/**
 * Themes: a `theme.css` of CSS custom properties in three scopes, as on every patra page:
 *
 *   light          :root { ... }
 *   dark, system   @media (prefers-color-scheme: dark) { :root:not([data-theme="light"]) { ... } }
 *   dark, chosen   :root[data-theme="dark"] { ... }
 *
 * A theme fits a template when it defines every token the template uses, and every colour token
 * in all three scopes, so no viewer ever gets one scheme's text on the other's background. Fonts
 * and shapes (`--font-*`, `--radius-*`, `--space-*`) are defined once.
 */

export interface Theme {
  readonly file: string;
  readonly css: string;
  readonly light: ReadonlySet<string>;
  readonly darkSystem: ReadonlySet<string>;
  readonly darkChosen: ReadonlySet<string>;
}

const LIGHT = ':root';
const DARK_SYSTEM = ':root:not([data-theme="light"])';
const DARK_CHOSEN = ':root[data-theme="dark"]';
const DARK_MEDIA = '@media (prefers-color-scheme: dark)';
const MODE_INDEPENDENT = /^--(font|radius|space)-/;

/** Strip comments, keeping offsets irrelevant: themes are small and hand-written. */
function stripComments(css: string): string {
  return css.replace(/\/\*[\s\S]*?\*\//g, '');
}

interface Block {
  readonly selector: string;
  readonly body: string;
}

/** Top-level `selector { body }` blocks, matching braces. */
function blocks(css: string): Block[] {
  const found: Block[] = [];
  let depth = 0;
  let start = 0;
  let selectorStart = 0;
  for (let i = 0; i < css.length; i++) {
    const c = css[i];
    if (c === '{') {
      if (depth === 0) start = i;
      depth++;
    } else if (c === '}') {
      depth--;
      if (depth === 0) {
        found.push({
          selector: css.slice(selectorStart, start).trim().replace(/\s+/g, ' '),
          body: css.slice(start + 1, i),
        });
        selectorStart = i + 1;
      }
    }
  }
  return found;
}

function declared(body: string): Set<string> {
  return new Set([...body.matchAll(/(--[a-z][a-z0-9-]*)\s*:/g)].map((m) => m[1] ?? ''));
}

export type ThemeResult =
  | { readonly ok: true; readonly theme: Theme }
  | { readonly ok: false; readonly problems: readonly Problem[] };

export function loadTheme(path: string, file = 'theme.css'): ThemeResult {
  if (!existsSync(path)) {
    return {
      ok: false,
      problems: [{ file, at: '', code: 'MISSING_FILE', message: `${path} does not exist` }],
    };
  }
  const css = readFileSync(path, 'utf8');
  const light = new Set<string>();
  const darkSystem = new Set<string>();
  const darkChosen = new Set<string>();
  for (const block of blocks(stripComments(css))) {
    if (block.selector === LIGHT) for (const t of declared(block.body)) light.add(t);
    else if (block.selector === DARK_CHOSEN)
      for (const t of declared(block.body)) darkChosen.add(t);
    else if (block.selector === DARK_MEDIA) {
      for (const inner of blocks(block.body)) {
        if (inner.selector === DARK_SYSTEM) for (const t of declared(inner.body)) darkSystem.add(t);
      }
    }
  }
  return { ok: true, theme: { file, css, light, darkSystem, darkChosen } };
}

/** What a theme is missing for a template that uses these tokens. */
export function themeProblems(theme: Theme, tokens: readonly string[]): Problem[] {
  const problems: Problem[] = [];
  for (const token of tokens) {
    if (!theme.light.has(token)) {
      problems.push({
        file: theme.file,
        at: '',
        code: 'MISSING_TOKEN',
        message: `${token} is used by the template but not defined in ${LIGHT}`,
      });
      continue;
    }
    if (MODE_INDEPENDENT.test(token)) continue;
    const missing = [
      theme.darkSystem.has(token) ? undefined : `${DARK_MEDIA} ${DARK_SYSTEM}`,
      theme.darkChosen.has(token) ? undefined : DARK_CHOSEN,
    ].filter((scope): scope is string => scope !== undefined);
    if (missing.length > 0) {
      problems.push({
        file: theme.file,
        at: '',
        code: 'MISSING_DARK_TOKEN',
        message: `${token} has no dark value in ${missing.join(' and ')}`,
      });
    }
  }
  return problems;
}
