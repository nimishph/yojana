import Mustache from 'mustache';
import type { Problem } from './problem.ts';

type Token = [string, string, number, number, Token[]?, ...unknown[]];

/**
 * Problems with a template's markup: syntax errors, raw output (`{{{x}}}`, `{{& x}}`), delimiter
 * changes, and partials that name no part. Checked on tokens, not text, so no delimiter trick
 * gets past it.
 */
export function templateProblems(
  file: string,
  html: string,
  partNames: ReadonlySet<string>,
): Problem[] {
  let tokens: Token[];
  try {
    tokens = Mustache.parse(html) as unknown as Token[];
  } catch (error) {
    return [{ file, at: '', code: 'TEMPLATE_SYNTAX', message: String(error) }];
  }
  const problems: Problem[] = [];
  const walk = (list: readonly Token[]) => {
    for (const token of list) {
      const [type, value] = token;
      if (type === '&' || type === '{') {
        problems.push({
          file,
          at: '',
          code: 'RAW_OUTPUT',
          message: `{{{${value}}}} would output content unescaped; use {{${value}}} (formatted values render as HTML on their own)`,
        });
      } else if (type === '=') {
        problems.push({
          file,
          at: '',
          code: 'DELIMITER_CHANGE',
          message: 'changing Mustache delimiters is not allowed in patra templates',
        });
      } else if (type === '>' && !partNames.has(value)) {
        problems.push({
          file,
          at: '',
          code: 'UNKNOWN_PART',
          message: `{{> ${value}}} names no part`,
        });
      }
      const children = token[4];
      if (Array.isArray(children)) walk(children);
    }
  };
  walk(tokens);
  return problems;
}
