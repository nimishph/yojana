/**
 * Formatting: the only place patra produces markup. Everything that comes from an app is escaped
 * first; Markdown and diffs are built from escaped text, so no input can become live HTML.
 */

/** HTML that patra produced. Templates render it as is; any other value is escaped. */
export class SafeHtml {
  readonly html: string;

  constructor(html: string) {
    this.html = html;
  }

  toString(): string {
    return this.html;
  }
}

const ESCAPES: Readonly<Record<string, string>> = {
  '&': '&amp;',
  '<': '&lt;',
  '>': '&gt;',
  '"': '&quot;',
  "'": '&#39;',
  '`': '&#96;',
  '=': '&#61;',
};

export function escapeHtml(text: string): string {
  return text.replace(/[&<>"'`=]/g, (c) => ESCAPES[c] ?? c);
}

/** A span of text to mark, e.g. the quote a comment thread is pinned to. */
export interface Mark {
  readonly text: string;
  /** Becomes `data-mark` on the `<mark>`, so the page can tie it to a thread. */
  readonly id: string;
}

function inline(text: string): string {
  return escapeHtml(text)
    .replace(/&#96;(.+?)&#96;/g, '<code>$1</code>')
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
}

/** Wrap the first occurrence of each mark's text (as rendered) in a `<mark>`. */
function applyMarks(html: string, marks: readonly Mark[]): string {
  let result = html;
  for (const mark of marks) {
    const needle = escapeHtml(mark.text);
    if (needle === '' || !result.includes(needle)) continue;
    result = result.replace(needle, `<mark data-mark="${escapeHtml(mark.id)}">${needle}</mark>`);
  }
  return result;
}

/**
 * A small Markdown subset: paragraphs, fenced code, `##`-`######` headings (rendered one level
 * below the template's own), `-`/`*`/`1.` list items, inline code and bold. Anything else is text.
 */
export function renderMarkdown(source: string, marks: readonly Mark[] = []): SafeHtml {
  const out: string[] = [];
  let paragraph: string[] = [];
  let list: string[] = [];
  let code: string[] | undefined;
  const mark = (html: string) => applyMarks(html, marks);
  const flush = () => {
    if (paragraph.length > 0) out.push(`<p>${mark(inline(paragraph.join(' ')))}</p>`);
    if (list.length > 0)
      out.push(`<ul>${list.map((i) => `<li>${mark(inline(i))}</li>`).join('')}</ul>`);
    paragraph = [];
    list = [];
  };
  for (const line of source.replace(/\r\n?/g, '\n').split('\n')) {
    if (code !== undefined) {
      if (/^ {0,3}(`{3,}|~{3,})\s*$/.test(line)) {
        out.push(`<pre><code>${escapeHtml(code.join('\n'))}</code></pre>`);
        code = undefined;
      } else {
        code.push(line);
      }
      continue;
    }
    if (/^ {0,3}(`{3,}|~{3,})/.test(line)) {
      flush();
      code = [];
      continue;
    }
    const heading = /^#{2,6}\s+(.*)$/.exec(line);
    if (heading !== null) {
      flush();
      out.push(`<h4>${inline(heading[1] ?? '')}</h4>`);
      continue;
    }
    const item = /^\s*(?:[-*]|\d+\.)\s+(.*)$/.exec(line);
    if (item !== null) {
      if (paragraph.length > 0) flush();
      list.push(item[1] ?? '');
      continue;
    }
    if (line.trim() === '') {
      flush();
      continue;
    }
    if (list.length > 0) flush();
    paragraph.push(line.trim());
  }
  if (code !== undefined) out.push(`<pre><code>${escapeHtml(code.join('\n'))}</code></pre>`);
  flush();
  return new SafeHtml(out.join('\n'));
}

/** Words and the whitespace between them, so a diff can put text back together exactly. */
function tokens(text: string): string[] {
  return text.match(/\s+|[^\s]+/g) ?? [];
}

type Op = { readonly kind: 'same' | 'del' | 'ins'; readonly text: string };

/** Longest common subsequence over tokens; returns the edit script in order. */
/** Below this share of words kept, a diff shows old and new text whole instead of interleaved. */
const SIMILAR_ENOUGH_TO_INTERLEAVE = 0.4;

function lcsDiff(a: readonly string[], b: readonly string[]): Op[] {
  const rows = a.length + 1;
  const cols = b.length + 1;
  const table = new Uint32Array(rows * cols);
  for (let i = a.length - 1; i >= 0; i--) {
    for (let j = b.length - 1; j >= 0; j--) {
      table[i * cols + j] =
        a[i] === b[j]
          ? (table[(i + 1) * cols + j + 1] ?? 0) + 1
          : Math.max(table[(i + 1) * cols + j] ?? 0, table[i * cols + j + 1] ?? 0);
    }
  }
  const ops: Op[] = [];
  let i = 0;
  let j = 0;
  while (i < a.length && j < b.length) {
    if (a[i] === b[j]) {
      ops.push({ kind: 'same', text: a[i] ?? '' });
      i++;
      j++;
    } else if ((table[(i + 1) * cols + j] ?? 0) >= (table[i * cols + j + 1] ?? 0)) {
      ops.push({ kind: 'del', text: a[i] ?? '' });
      i++;
    } else {
      ops.push({ kind: 'ins', text: b[j] ?? '' });
      j++;
    }
  }
  for (; i < a.length; i++) ops.push({ kind: 'del', text: a[i] ?? '' });
  for (; j < b.length; j++) ops.push({ kind: 'ins', text: b[j] ?? '' });
  return ops;
}

/**
 * Word-level diff as `<del>` and `<ins>`, escaped. A changed phrase reads as one deletion and one
 * insertion: a space between two changed words belongs to the change, not to the unchanged text.
 * Whitespace-only differences are not shown as changes.
 */
export function renderDiff(before: string, after: string): SafeHtml {
  const normalize = (text: string) => text.replace(/\s+/g, ' ').trim();
  const a = normalize(before);
  const b = normalize(after);
  const ops = lcsDiff(tokens(a), tokens(b));

  // A rewrite, not an edit: show the old text and the new one whole, not interleaved fragments.
  const words = (text: string) => tokens(text).filter((t) => t.trim() !== '').length;
  const kept = ops.filter((op) => op.kind === 'same' && op.text.trim() !== '').length;
  const longest = Math.max(words(a), words(b));
  if (longest > 0 && kept / longest < SIMILAR_ENOUGH_TO_INTERLEAVE && a !== '' && b !== '') {
    return new SafeHtml(`<del>${escapeHtml(a)}</del> <ins>${escapeHtml(b)}</ins>`);
  }

  const out: string[] = [];
  let removed = '';
  let added = '';
  const flush = () => {
    if (removed !== '') out.push(`<del>${escapeHtml(removed)}</del>`);
    // A space between the two, so "old</del><ins>new" never reads as one word.
    if (removed !== '' && added !== '') out.push(' ');
    if (added !== '') out.push(`<ins>${escapeHtml(added)}</ins>`);
    removed = '';
    added = '';
  };
  ops.forEach((op, index) => {
    if (op.kind === 'del') removed += op.text;
    else if (op.kind === 'ins') added += op.text;
    else {
      const between = op.text.trim() === '' && (removed !== '' || added !== '');
      const next = ops[index + 1];
      if (between && next !== undefined && next.kind !== 'same') {
        if (removed !== '') removed += op.text;
        if (added !== '') added += op.text;
        return;
      }
      flush();
      out.push(escapeHtml(op.text));
    }
  });
  flush();
  return new SafeHtml(out.join(''));
}
