import { join } from 'node:path';

/** The stylesheet of one of patra's themes, for `loadTheme` or `serve`. */
export function themeFile(name: 'default'): string {
  return join(import.meta.dir, name, 'theme.css');
}
