/// <reference path="./htmx.d.ts" />
import { randomUUID } from 'node:crypto';
import {
  type ContentSource,
  escapeHtml,
  type Intent,
  type IntentAnswer,
  type IntentHandler,
  type LoadedTemplate,
  PatraError,
  pageHead,
  renderPage,
  renderPart,
  resolvePointer,
  SafeHtml,
} from '@cntxt-labs/patra-core';
import htmxSource from 'htmx.org/dist/htmx.min.js' with { type: 'text' };
import { RUNTIME_SCRIPT, RUNTIME_STYLES } from './runtime.ts';

/**
 * patra-serve: templates served live on this machine.
 *
 *   GET  /d/<template>/<document>                 the page
 *   GET  /f/<template>/<document>/<action>?key=   the action's form, opened on one item
 *   POST /i/<template>/<document>/<action>        an intent (form-encoded; _key, _version, fields)
 *   POST /refresh/<template>/<document>/          ask the app to refresh, then reload
 *   GET  /assets/htmx.js, /assets/patra.js        htmx (pinned, 0BSD) and the page runtime
 *
 * Answers are HTML for htmx. An accepted intent re-renders the item in every part that shows it
 * (the acted-on part in place, the others out of band) or reloads the page; a refused one comes
 * back as the same form with what was typed and why, or as an error in the item's slot.
 *
 * Writes need the page's token (sent by htmx as a header) and a Host of this server, and run one
 * at a time. Binds to 127.0.0.1 only.
 */

export interface ServeOptions {
  readonly templates: readonly LoadedTemplate[];
  readonly themeCss: string;
  readonly source: ContentSource;
  readonly handle: IntentHandler;
  /** Who acts, as the app should record it. */
  readonly actor: string;
  /** 0 picks a free port. */
  readonly port?: number | undefined;
  /** Extra head markup the host trusts (fonts, favicons). */
  readonly head?: readonly string[] | undefined;
  /** Seconds a request may run; slow apps (checks, trackers) need more than Bun's default 10. */
  readonly idleTimeout?: number | undefined;
}

export interface PatraServer {
  readonly url: string;
  readonly token: string;
  /** The URL of a document's page. */
  page(template: string, document: string): string;
  stop(): void;
}

/** htmx swaps 4xx answers too, so a refused form comes back in place with its reason. */
const HTMX_CONFIG = JSON.stringify({
  responseHandling: [
    { code: '204', swap: false },
    { code: '[23]..', swap: true },
    { code: '4..', swap: true, error: false },
    { code: '...', swap: false, error: true },
  ],
});

/** Bun's default is 10 s; refreshes that run checks or ask a tracker can take longer. */
const DEFAULT_IDLE_SECONDS = 120;
/** Form field names patra uses itself; never sent to the app as payload. */
const RESERVED = new Set(['_key', '_version']);

function html(body: string, status = 200, headers: Record<string, string> = {}): Response {
  return new Response(body, {
    status,
    headers: {
      'content-type': 'text/html; charset=utf-8',
      'cache-control': 'no-store',
      ...headers,
    },
  });
}

function errorHtml(message: string): string {
  return `<p class="error" role="alert">${escapeHtml(message)}</p>`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** A CSS selector for one item of a part, safe for any key. */
function itemSelector(part: string, key: string): string {
  const quote = (v: string) => `"${v.replaceAll('\\', '\\\\').replaceAll('"', '\\"')}"`;
  return `[data-patra-part=${quote(part)}][data-patra-key=${quote(key)}]`;
}

/** Mark a rendered element to be swapped out of band into the matching element on the page. */
function outOfBand(rendered: string, selector: string): string {
  const attribute = ` hx-swap-oob="outerHTML:${escapeHtml(selector)}"`;
  return rendered.replace(/^(\s*<[a-zA-Z][\w-]*)/, `$1${attribute}`);
}

export function serve(options: ServeOptions): PatraServer {
  const token = randomUUID();
  const templates = new Map(options.templates.map((t) => [t.manifest.id, t]));
  let lastWrite: Promise<void> = Promise.resolve();

  /** Writes wait for the one before, so the app never sees two at once. */
  const oneAtATime = async <T>(work: () => Promise<T>): Promise<T> => {
    const previous = lastWrite;
    let release = (): void => undefined;
    lastWrite = new Promise<void>((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await work();
    } finally {
      release();
    }
  };

  const config = (template: LoadedTemplate, document: string) =>
    JSON.stringify({
      template: template.manifest.id,
      document,
      token,
      actions: Object.fromEntries(
        Object.entries(template.manifest.actions).map(([name, a]) => [
          name,
          { part: a.part, form: a.form !== undefined },
        ]),
      ),
    }).replace(/</g, '\\u003c');

  const page = async (template: LoadedTemplate, document: string): Promise<Response> => {
    const content = await options.source.load(template.manifest.id, document);
    if (content === undefined) return html(errorHtml(`No document ${document}.`), 404);
    const head = pageHead(template, options.themeCss, [
      ...(options.head ?? []),
      `<style>${RUNTIME_STYLES}</style>`,
      `<meta name="htmx-config" content="${escapeHtml(HTMX_CONFIG)}">`,
      '<script src="/assets/htmx.js"></script>',
    ]);
    const foot = new SafeHtml(
      `<script type="application/json" id="patra-config">${config(template, document)}</script>\n<script src="/assets/patra.js"></script>`,
    );
    const rendered = renderPage(template, content, { head, foot, document });
    if (!rendered.ok) {
      const lines = rendered.problems.map((p) => `${p.file}${p.at}: ${p.message}`).join('\n');
      return html(
        `<pre>${escapeHtml(`This document does not fit the template:\n${lines}`)}</pre>`,
        500,
      );
    }
    return html(rendered.html);
  };

  /** The item an action targets, from the document's current content. */
  const findItem = async (
    template: LoadedTemplate,
    document: string,
    part: string,
    key: string,
  ) => {
    const spec = template.parts.get(part);
    const content = await options.source.load(template.manifest.id, document);
    if (spec?.collection === undefined || spec.key === undefined || content === undefined) {
      return undefined;
    }
    const items = resolvePointer(content, spec.collection);
    if (!Array.isArray(items)) return undefined;
    const keyField = spec.key;
    return items.find((i) => isRecord(i) && i[keyField] === key) as
      | Record<string, unknown>
      | undefined;
  };

  const formHtml = (
    template: LoadedTemplate,
    action: string,
    item: Record<string, unknown>,
    values: Record<string, string>,
    error?: string,
  ): string | undefined => {
    const spec = template.manifest.actions[action];
    if (spec?.form === undefined) return undefined;
    const rendered = renderPart(template, spec.form, {
      ...item,
      values,
      ...(error === undefined ? {} : { error }),
    });
    return rendered.ok
      ? rendered.html
      : errorHtml(rendered.problems.map((p) => p.message).join('; '));
  };

  const form = async (
    template: LoadedTemplate,
    document: string,
    action: string,
    query: URLSearchParams,
  ): Promise<Response> => {
    const spec = template.manifest.actions[action];
    if (spec === undefined) return html(errorHtml(`No action ${action}.`), 404);
    const key = query.get('key') ?? '';
    const item = await findItem(template, document, spec.part, key);
    if (item === undefined)
      return html(errorHtml(`${key} is not on this page any more; reload it.`), 404);
    const values: Record<string, string> = {};
    for (const [field, pointer] of Object.entries(spec.defaults ?? {})) {
      const value = resolvePointer(item, pointer);
      if (typeof value === 'string') values[field] = value;
    }
    for (const field of spec.fields) {
      const given = query.get(field);
      if (given !== null) values[field] = given;
    }
    return html(formHtml(template, action, item, values) ?? errorHtml(`${action} has no form.`));
  };

  const answer = async (
    template: LoadedTemplate,
    document: string,
    intent: Intent,
    result: IntentAnswer,
  ): Promise<Response> => {
    if (result.ok) {
      if (result.update.kind === 'page') return html('', 200, { 'HX-Refresh': 'true' });
      const { part, key, content } = result.update;
      const main = renderPart(template, part, content);
      if (!main.ok) return html(errorHtml(main.problems.map((p) => p.message).join('; ')), 500);
      // The same item shown by other parts (an outline entry for a section) is updated too.
      const collection = template.parts.get(part)?.collection;
      const others = [...template.parts.values()]
        .filter((p) => p.name !== part && p.collection !== undefined && p.collection === collection)
        .flatMap((p) => {
          const rendered = renderPart(template, p.name, content);
          return rendered.ok ? [outOfBand(rendered.html, itemSelector(p.name, key))] : [];
        });
      return html([main.html, ...others].join('\n'), 200, {
        'HX-Retarget': itemSelector(part, key),
        'HX-Reswap': 'outerHTML',
      });
    }
    const status = result.code === 'STALE' ? 409 : 400;
    const item = await findItem(template, document, intent.target.part, intent.target.key);
    const message =
      result.code === 'STALE' && result.current !== undefined
        ? `${result.message} Reload to see the current version; what you typed is kept below.`
        : result.message;
    const again =
      item === undefined
        ? undefined
        : formHtml(template, intent.action, item, { ...intent.payload }, message);
    return html(again ?? errorHtml(message), status);
  };

  const intent = async (
    template: LoadedTemplate,
    document: string,
    action: string,
    request: Request,
  ): Promise<Response> => {
    const spec = template.manifest.actions[action];
    if (spec === undefined && action !== 'refresh')
      return html(errorHtml(`No action ${action}.`), 404);
    const fields: Record<string, string> = {};
    // A refresh, or an action without a form, may post no body at all.
    const type = request.headers.get('content-type') ?? '';
    if (type.includes('form-urlencoded') || type.includes('multipart/form-data')) {
      (await request.formData()).forEach((value, name) => {
        if (typeof value === 'string') fields[name] = value;
      });
    }
    const payload = Object.fromEntries(
      Object.entries(fields).filter(
        ([name]) => !RESERVED.has(name) && (spec?.fields.includes(name) ?? false),
      ),
    );
    const built: Intent = {
      template: template.manifest.id,
      document,
      action,
      target: { part: spec?.part ?? '', key: fields._key ?? '' },
      ...(fields._version ? { version: fields._version } : {}),
      payload,
      actor: options.actor,
    };
    const result = await oneAtATime(() => options.handle(built));
    return answer(template, document, built, result);
  };

  const server = Bun.serve({
    hostname: '127.0.0.1',
    port: options.port ?? 0,
    idleTimeout: options.idleTimeout ?? DEFAULT_IDLE_SECONDS,
    async fetch(request) {
      const url = new URL(request.url);
      const host = request.headers.get('host') ?? '';
      if (host !== `127.0.0.1:${url.port}` && host !== `localhost:${url.port}`) {
        return html(errorHtml('Unexpected host.'), 403);
      }
      if (url.pathname === '/assets/htmx.js') {
        return new Response(htmxSource, {
          headers: { 'content-type': 'text/javascript; charset=utf-8' },
        });
      }
      if (url.pathname === '/assets/patra.js') {
        return new Response(RUNTIME_SCRIPT, {
          headers: { 'content-type': 'text/javascript; charset=utf-8' },
        });
      }
      const [, kind, templateId = '', document = '', action = ''] = url.pathname
        .split('/')
        .map((p) => decodeURIComponent(p));
      const template = templates.get(templateId);
      if (template === undefined) return html(errorHtml('Not found.'), 404);
      try {
        if (request.method === 'GET' && kind === 'd') return await page(template, document);
        if (request.method === 'GET' && kind === 'f')
          return await form(template, document, action, url.searchParams);
        if (request.method === 'POST' && (kind === 'i' || kind === 'refresh')) {
          if (request.headers.get('x-patra-token') !== token) {
            return html(errorHtml('This page is out of date; reload it.'), 403);
          }
          return await intent(template, document, kind === 'refresh' ? 'refresh' : action, request);
        }
        return html(errorHtml('Not found.'), 404);
      } catch (error) {
        const message = error instanceof PatraError ? error.message : String(error);
        return html(errorHtml(message), 500);
      }
    },
  });

  return {
    url: `http://127.0.0.1:${server.port}`,
    token,
    page: (template, document) =>
      `http://127.0.0.1:${server.port}/d/${encodeURIComponent(template)}/${encodeURIComponent(document)}`,
    stop: () => server.stop(true),
  };
}
