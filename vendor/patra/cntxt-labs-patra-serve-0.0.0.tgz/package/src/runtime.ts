/**
 * The page runtime: the one script a served page runs besides htmx. It reads the page's config
 * (template, document, token, declared actions) and turns a template's data-patra-* markers into
 * behaviour, without the template naming a single URL:
 *
 *   data-patra-part / -key / -version   an item; actions inside it act on it
 *   data-patra-action="x"               opens x's form in the item's slot, or posts x directly
 *   data-patra-form="x"                 submitting posts the intent; the answer swaps in place
 *   data-patra-slot                     where an item's forms and errors appear
 *   data-patra-cancel                   closes the form it is in
 *   data-patra-select                   selecting text there offers the item's comment/suggest
 *   data-patra-mode="x"                 sets data-mode on the [data-mode] root (kept in ?mode=)
 *   data-patra-tabs / -tab / -panel     tabs
 *   data-patra-filter="x" / -tags       show only items tagged x (click again to show all)
 *   data-patra-refresh                  asks the app to refresh, then reloads
 *
 * Keyboard: j / k next and previous item, e / s / c edit, suggest, comment on it (c with text
 * selected comments on the selection), Ctrl/Cmd+Enter sends the open form, r refresh, ? help,
 * Escape closes. Plain ES5-style JavaScript in a raw string: nothing is interpolated.
 */
export const RUNTIME_SCRIPT = String.raw`
(function () {
  var cfg = JSON.parse(document.getElementById('patra-config').textContent);
  var enc = encodeURIComponent;
  var base = '/' + enc(cfg.template) + '/' + enc(cfg.document) + '/';
  var urls = {
    form: function (action) { return '/f' + base + enc(action); },
    intent: function (action) { return '/i' + base + enc(action); },
    refresh: '/refresh' + base
  };
  document.documentElement.setAttribute('data-patra-live', '');

  // Page-level answers (a refresh, an error with nowhere else to go) appear here.
  var status = document.createElement('div');
  status.className = 'patra-status';
  status.setAttribute('role', 'status');
  status.setAttribute('aria-live', 'polite');
  document.body.appendChild(status);
  function refresh() {
    status.textContent = 'Refreshing…';
    return htmx.ajax('POST', urls.refresh, { target: status, swap: 'innerHTML' });
  }
  document.body.setAttribute('hx-headers', JSON.stringify({ 'x-patra-token': cfg.token }));

  function itemOf(el) { return el && el.closest('[data-patra-part][data-patra-key]'); }
  function slotOf(item) {
    var slots = item.querySelectorAll('[data-patra-slot]');
    for (var i = 0; i < slots.length; i++) if (itemOf(slots[i]) === item) return slots[i];
    return null;
  }
  function actionsFor(part) {
    return Object.keys(cfg.actions).filter(function (name) { return cfg.actions[name].part === part; });
  }

  // Modes, kept in the URL so a reload or a shared link keeps them.
  var root = document.querySelector('[data-mode]');
  function setMode(mode) {
    if (!root) return;
    root.setAttribute('data-mode', mode);
    document.querySelectorAll('[data-patra-mode]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-patra-mode') === mode));
    });
    var url = new URL(location.href);
    url.searchParams.set('mode', mode);
    history.replaceState(null, '', url);
  }
  var urlMode = new URL(location.href).searchParams.get('mode');
  if (urlMode && document.querySelector('[data-patra-mode="' + CSS.escape(urlMode) + '"]')) setMode(urlMode);
  else if (root) setMode(root.getAttribute('data-mode'));

  // Tabs.
  document.querySelectorAll('[data-patra-tabs]').forEach(function (group) {
    var tabs = group.querySelectorAll('[data-patra-tab]');
    function show(name) {
      tabs.forEach(function (t) { t.setAttribute('aria-selected', String(t.getAttribute('data-patra-tab') === name)); });
      group.querySelectorAll('[data-patra-panel]').forEach(function (p) { p.hidden = p.getAttribute('data-patra-panel') !== name; });
    }
    tabs.forEach(function (t) { t.addEventListener('click', function () { show(t.getAttribute('data-patra-tab')); }); });
    if (tabs.length > 0) show(tabs[0].getAttribute('data-patra-tab'));
  });

  // Filters: one active at a time; clicking the active one shows everything.
  var activeFilter = null;
  function applyFilter() {
    document.querySelectorAll('[data-patra-filter]').forEach(function (b) {
      b.setAttribute('aria-pressed', String(b.getAttribute('data-patra-filter') === activeFilter));
    });
    document.querySelectorAll('[data-patra-tags]').forEach(function (el) {
      var tags = (el.getAttribute('data-patra-tags') || '').split(/\s+/);
      el.hidden = activeFilter !== null && tags.indexOf(activeFilter) === -1;
    });
  }
  var initial = document.querySelector('[data-patra-filter][data-active="true"]');
  if (initial) activeFilter = initial.getAttribute('data-patra-filter');
  applyFilter();

  // Opening forms and posting actions.
  function params(item, button, extra) {
    var p = new URLSearchParams();
    p.set('key', item.getAttribute('data-patra-key'));
    ['item', 'decision'].forEach(function (name) {
      var value = button && button.getAttribute('data-patra-' + name);
      if (value) p.set(name, value);
    });
    Object.keys(extra || {}).forEach(function (k) { p.set(k, extra[k]); });
    return p;
  }
  function act(action, item, button, extra, target) {
    var spec = cfg.actions[action];
    if (!spec || !item) return Promise.resolve();
    var slot = target || slotOf(item);
    if (spec.form) {
      return htmx.ajax('GET', urls.form(action) + '?' + params(item, button, extra), { target: slot, swap: 'innerHTML' }).then(function () {
        var input = slot && slot.querySelector('textarea, input:not([type=hidden])');
        if (input) input.focus();
      });
    }
    return htmx.ajax('POST', urls.intent(action), {
      target: slot,
      swap: 'innerHTML',
      values: { _key: item.getAttribute('data-patra-key'), _version: item.getAttribute('data-patra-version') || '' }
    });
  }

  document.addEventListener('click', function (event) {
    var cancel = event.target.closest('[data-patra-cancel]');
    if (cancel) {
      var form = cancel.closest('form');
      if (form) form.remove();
      hidePop();
      return;
    }
    var mode = event.target.closest('[data-patra-mode]');
    if (mode) { setMode(mode.getAttribute('data-patra-mode')); return; }
    var filter = event.target.closest('[data-patra-filter]');
    if (filter) {
      var id = filter.getAttribute('data-patra-filter');
      activeFilter = activeFilter === id ? null : id;
      applyFilter();
      return;
    }
    if (event.target.closest('[data-patra-refresh]')) {
      refresh();
      return;
    }
    var button = event.target.closest('[data-patra-action]');
    if (button) act(button.getAttribute('data-patra-action'), itemOf(button), button);
  });

  // Submitting a form posts its intent; the answer replaces the form (a refusal, with what was
  // typed) or, when it went through, the item itself (the server retargets).
  document.addEventListener('submit', function (event) {
    var form = event.target.closest('form[data-patra-form]');
    if (!form) return;
    event.preventDefault();
    var item = itemOf(form) || popFor;
    if (!item) return;
    var values = { _key: item.getAttribute('data-patra-key'), _version: item.getAttribute('data-patra-version') || '' };
    new FormData(form).forEach(function (value, name) { values[name] = value; });
    form.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
    htmx.ajax('POST', urls.intent(form.getAttribute('data-patra-form')), { source: form, target: form, swap: 'outerHTML', values: values });
  });

  // After any swap, newly arrived items follow the current filter.
  document.body.addEventListener('htmx:afterSettle', applyFilter);

  // Selection: a small toolbar by the selection offers the item's comment and suggest.
  var bar = document.createElement('div');
  bar.className = 'patra-selbar';
  bar.hidden = true;
  var pop = document.createElement('div');
  pop.className = 'patra-pop';
  pop.hidden = true;
  document.body.appendChild(bar);
  document.body.appendChild(pop);
  var picked = null;
  var popFor = null;
  function hideBar() { bar.hidden = true; }
  function hidePop() { pop.hidden = true; pop.textContent = ''; popFor = null; showQuote(null); }
  // While the comment popover is open the page keeps the quoted text marked (the selection itself
  // goes when the focus moves to the box), where the browser has the CSS Custom Highlight API.
  function showQuote(range) {
    if (!window.CSS || !CSS.highlights || typeof Highlight === 'undefined') return;
    if (range) CSS.highlights.set('patra-quote', new Highlight(range));
    else CSS.highlights.delete('patra-quote');
  }
  function place(el, rect, below) {
    el.style.top = (window.scrollY + (below ? rect.bottom + 8 : rect.top - 44)) + 'px';
    el.style.left = Math.max(16, Math.min(window.scrollX + rect.left, window.scrollX + document.documentElement.clientWidth - el.offsetWidth - 16)) + 'px';
  }
  // The text box a selection belongs to: the one it starts in, else (a drag begun on a heading or
  // in a gap) the first one it reaches.
  function boxOf(range) {
    var start = range.startContainer.nodeType === 1 ? range.startContainer : range.startContainer.parentElement;
    var box = start && start.closest('[data-patra-select]');
    if (box) return box;
    var all = document.querySelectorAll('[data-patra-select]');
    for (var i = 0; i < all.length; i++) if (range.intersectsNode(all[i])) return all[i];
    return null;
  }
  // The part of a range inside one box: a triple-click, or a drag that runs on into the buttons or
  // the next section, still quotes only this item's text.
  function within(range, box) {
    var inside = document.createRange();
    inside.selectNodeContents(box);
    var r = range.cloneRange();
    if (r.compareBoundaryPoints(Range.START_TO_START, inside) < 0) r.setStart(inside.startContainer, inside.startOffset);
    if (r.compareBoundaryPoints(Range.END_TO_END, inside) > 0) r.setEnd(inside.endContainer, inside.endOffset);
    return r;
  }
  function selection() {
    var sel = window.getSelection();
    if (!sel || sel.isCollapsed || sel.rangeCount === 0) return null;
    var whole = sel.getRangeAt(0);
    var box = boxOf(whole);
    if (!box) return null;
    var range = within(whole, box);
    var item = itemOf(box);
    var text = range.toString().replace(/\s+/g, ' ').trim();
    if (!item || text === '') return null;
    var offered = ['comment', 'suggest'].filter(function (a) { return actionsFor(item.getAttribute('data-patra-part')).indexOf(a) !== -1; });
    if (offered.length === 0) return null;
    return { item: item, quote: text, range: range, rect: range.getBoundingClientRect(), offered: offered };
  }
  var TOP_CLEARANCE = 80;
  function onSelection(action) {
    var chosen = picked;
    if (!chosen) return;
    hideBar();
    if (action !== 'comment') { act(action, chosen.item, null, {}); return; }
    popFor = chosen.item;
    act('comment', chosen.item, null, { quote: chosen.quote }, pop).then(function () {
      pop.hidden = false;
      place(pop, chosen.range.getBoundingClientRect(), true);
      showQuote(chosen.range);
      pop.scrollIntoView({ block: 'nearest' });
      var box = pop.querySelector('textarea');
      if (box) box.focus({ preventScroll: true });
    });
  }
  var pending = false;
  document.addEventListener('selectionchange', function () {
    if (pending || pop.contains(document.activeElement)) return;
    pending = true;
    setTimeout(function () {
      pending = false;
      picked = selection();
      if (!picked) { hideBar(); return; }
      bar.textContent = '';
      picked.offered.forEach(function (action) {
        var b = document.createElement('button');
        b.type = 'button';
        b.textContent = action === 'comment' ? 'Comment' : 'Suggest edit';
        b.title = action === 'comment' ? 'Comment on the selection (c)' : 'Suggest an edit (s)';
        b.setAttribute('data-patra-sel', action);
        bar.appendChild(b);
      });
      bar.hidden = false;
      // Above the selection, unless the sticky bar at the top of the page would cover it.
      place(bar, picked.rect, picked.rect.top < TOP_CLEARANCE);
    });
  });
  bar.addEventListener('mousedown', function (event) { event.preventDefault(); });
  bar.addEventListener('click', function (event) {
    var b = event.target.closest('[data-patra-sel]');
    if (!b || !picked) return;
    onSelection(b.getAttribute('data-patra-sel'));
  });
  document.body.addEventListener('htmx:afterRequest', function (event) {
    if (pop.contains(event.target) && event.detail.successful) hidePop();
  });
  document.addEventListener('mousedown', function (event) {
    if (!pop.hidden && !pop.contains(event.target) && !bar.contains(event.target)) hidePop();
  });

  // Keyboard.
  var help = document.createElement('div');
  help.className = 'patra-help';
  help.hidden = true;
  help.setAttribute('role', 'dialog');
  help.setAttribute('aria-label', 'Keyboard shortcuts');
  [['j / k', 'next / previous item'], ['e', 'edit'], ['s', 'suggest an edit'], ['c', 'comment (on the selection, if any)'], ['Ctrl+Enter', 'send the open form'], ['r', 'refresh'], ['?', 'this help'], ['Esc', 'close']].forEach(function (row) {
    var line = document.createElement('div');
    var key = document.createElement('kbd');
    key.textContent = row[0];
    line.appendChild(key);
    line.appendChild(document.createTextNode(' ' + row[1]));
    help.appendChild(line);
  });
  document.body.appendChild(help);
  var current = null;
  function items() {
    var main = document.querySelector('main') || document.body;
    return Array.prototype.filter.call(main.querySelectorAll('[data-patra-part][data-patra-key]'), function (el) {
      return !el.hidden && itemOf(el.parentElement) === null;
    });
  }
  function focusItem(el) {
    if (!el) return;
    if (current) current.removeAttribute('data-patra-current');
    current = el;
    el.setAttribute('data-patra-current', '');
    el.scrollIntoView({ block: 'nearest' });
  }
  document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') { hideBar(); hidePop(); help.hidden = true; return; }
    if (event.key === 'Enter' && (event.ctrlKey || event.metaKey)) {
      var sending = event.target && event.target.closest && event.target.closest('form[data-patra-form]');
      if (sending) { event.preventDefault(); sending.requestSubmit(); }
      return;
    }
    if (event.ctrlKey || event.metaKey || event.altKey) return;
    var t = event.target;
    if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
    var list = items();
    var at = current ? list.indexOf(current) : -1;
    if (event.key === 'j') focusItem(list[Math.min(list.length - 1, at + 1)]);
    else if (event.key === 'k') focusItem(list[Math.max(0, at - 1)]);
    else if (event.key === '?') help.hidden = !help.hidden;
    else if (event.key === 'r') refresh();
    else if (event.key === 'c' && picked && !bar.hidden) onSelection('comment');
    else if (current && (event.key === 'e' || event.key === 's' || event.key === 'c')) {
      var name = { e: 'edit', s: 'suggest', c: 'comment' }[event.key];
      var button = current.querySelector('[data-patra-action="' + name + '"]');
      if (button && button.offsetParent !== null) { event.preventDefault(); act(name, current, button); }
    } else return;
    event.preventDefault();
  });
})();
`;

/** Styles for what the runtime adds to a page: toolbar, popover, help, current item. */
export const RUNTIME_STYLES = `
.patra-selbar { position: absolute; z-index: 20; display: flex; gap: 2px; padding: 3px; background: var(--text); border-radius: var(--radius-md); box-shadow: 0 6px 18px rgba(0,0,0,.25); }
.patra-selbar[hidden], .patra-pop[hidden], .patra-help[hidden] { display: none; }
.patra-selbar button { background: transparent; border: 0; color: var(--surface-raised); padding: 4px 10px; font: 500 13px var(--font-ui); cursor: pointer; border-radius: var(--radius-sm); }
.patra-selbar button:hover, .patra-selbar button:focus-visible { background: color-mix(in srgb, var(--surface-raised) 18%, transparent); }
::highlight(patra-quote) { background-color: var(--mark); color: inherit; }
.patra-pop blockquote { margin: 10px 0 4px; padding-left: 8px; border-left: 3px solid var(--mark); color: var(--text-muted); font: italic 13.5px / 1.5 var(--font-reading); max-height: 6.5em; overflow: auto; }
.patra-pop { position: absolute; z-index: 20; width: min(420px, calc(100vw - 32px)); background: var(--surface-raised); border: 1px solid var(--intent-primary); border-radius: var(--radius-md); padding: 4px 14px 14px; box-shadow: 0 8px 24px rgba(0,0,0,.2); }
.patra-status:empty { display: none; }
.patra-status { position: fixed; z-index: 30; left: 16px; bottom: calc(16px + env(safe-area-inset-bottom, 0px)); max-width: min(520px, calc(100vw - 32px)); padding: 8px 12px; background: var(--surface-raised); border: 1px solid var(--border); border-radius: var(--radius-md); box-shadow: 0 8px 24px rgba(0,0,0,.2); font: 13.5px var(--font-ui); color: var(--text); }
.patra-status .error { margin: 0; }
.patra-help { position: fixed; z-index: 30; right: 16px; bottom: calc(16px + env(safe-area-inset-bottom, 0px)); display: grid; gap: 4px; padding: 12px 16px; background: var(--surface-raised); border: 1px solid var(--border); border-radius: var(--radius-md); box-shadow: 0 8px 24px rgba(0,0,0,.2); font: 13px var(--font-ui); color: var(--text); }
.patra-help kbd { font: 500 12px var(--font-mono); border: 1px solid var(--border); border-bottom-width: 2px; border-radius: var(--radius-sm); padding: 0 5px; }
[data-patra-current] { outline: 2px solid var(--intent-primary); outline-offset: 6px; border-radius: var(--radius-sm); }
`;
