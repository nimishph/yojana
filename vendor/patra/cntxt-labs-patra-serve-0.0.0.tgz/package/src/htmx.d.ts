/** htmx's minified build, imported as text (`with { type: 'text' }`) and served by patra-serve. */
declare module 'htmx.org/dist/htmx.min.js' {
  const source: string;
  export default source;
}
